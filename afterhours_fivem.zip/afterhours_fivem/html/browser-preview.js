// The NUI is hidden until FiveM sends its open message. When opened as a local
// file or ordinary browser page, show the UI with sample catalogue data instead.
if (typeof GetParentResourceName !== 'function') {
  const sample = {
    action: 'open', currentModel: 'nero',
    vehicles: [
      ['nero','Nero','SUPER',1500000,9.0,8.7], ['nero2','Nero Custom','SUPER',1850000,9.2,8.9],
      ['adder','Adder','SUPER',1000000,9.1,8.4], ['zentorno','Zentorno','SUPER',725000,8.9,8.6],
      ['krieger','Krieger','SUPER',2875000,9.4,9.2], ['xa21','XA-21','SUPER',2375000,9.0,9.0],
      ['vagner','Vagner','SUPER',1535000,9.3,9.1],
      ['elegy','Elegy RH8','SPORT',95000,8.6,8.1], ['jester','Jester','SPORT',142000,8.2,8.4],
      ['comet2','Comet','SPORT',125000,8.4,8.0], ['banshee','Banshee','SPORT',105000,8.9,7.6],
      ['sultanrs','Sultan RS','SUPER',180000,9.1,8.2], ['sultan','Sultan','SPORT',75000,7.8,7.8],
      ['futo','Futo','SPORT',32000,5.7,6.3], ['buffalo','Buffalo','MUSCLE',52000,7.4,6.8],
      ['dominator','Dominator','MUSCLE',65000,8.0,6.5], ['sentinel','Sentinel XS','COUPE',47000,6.8,7.1],
      ['kuruma','Kuruma','SPORT',95000,7.7,7.9], ['cheetah','Cheetah','SUPER',650000,9.0,8.5]
    ].map(([model,name,vehicleClass,price,power,grip])=>({model,name,class:vehicleClass,price,power,grip})),
    paints: [
      {name:'Pearl',r:235,g:230,b:214},{name:'Torch',r:220,g:30,b:42},{name:'Glacier',r:198,g:218,b:226},{name:'Voltage',r:245,g:180,b:35},
      {name:'Abyss',r:24,g:72,b:130},{name:'Acid',r:112,g:166,b:45},{name:'Amethyst',r:115,g:46,b:143},
      {name:'Carbon',r:35,g:39,b:43},{name:'Pearl',r:235,g:230,b:214}
    ],
    neons: [{name:'EMBER',r:242,g:45,b:38},{name:'ICE',r:48,g:157,b:255},{name:'VIOLET',r:172,g:65,b:255},{name:'MINT',r:51,g:231,b:180}],
    wheelTypes: [{id:0,name:'SPORT'},{id:1,name:'MUSCLE'},{id:2,name:'LOWRIDER'},{id:3,name:'SUV'},{id:4,name:'OFFROAD'},{id:5,name:'TUNER'},{id:7,name:'HIGH END'}]
  };
  window.dispatchEvent(new MessageEvent('message',{data:sample}));
  document.body.classList.add('browser-preview');
  window.setTimeout(()=>window.dispatchEvent(new MessageEvent('message',{data:{action:'vehicleSelected',model:'nero',wheelType:7,wheelCount:12,liveryCount:8,modCounts:{'11':5,'12':4,'13':4,'15':5,'16':5}}})),0);
}
