Config = {}

-- Vanilla GTA V vehicles only. Add-on cars must already be installed by the server.
Config.Vehicles = {
    { model = 'nero',        name = 'Nero',             class = 'SUPER',     price = 1500000, power = 9.0, grip = 8.7 },
    { model = 'nero2',       name = 'Nero Custom',      class = 'SUPER',     price = 1850000, power = 9.2, grip = 8.9 },
    { model = 'adder',       name = 'Adder',            class = 'SUPER',     price = 1000000, power = 9.1, grip = 8.4 },
    { model = 'zentorno',    name = 'Zentorno',         class = 'SUPER',     price = 725000,  power = 8.9, grip = 8.6 },
    { model = 'krieger',     name = 'Krieger',          class = 'SUPER',     price = 2875000, power = 9.4, grip = 9.2 },
    { model = 'xa21',        name = 'XA-21',            class = 'SUPER',     price = 2375000, power = 9.0, grip = 9.0 },
    { model = 'vagner',      name = 'Vagner',           class = 'SUPER',     price = 1535000, power = 9.3, grip = 9.1 },
    { model = 'elegy',       name = 'Elegy RH8',       class = 'SPORT',     price = 95000,  power = 8.6, grip = 8.1 },
    { model = 'jester',      name = 'Jester',          class = 'SPORT',     price = 142000, power = 8.2, grip = 8.4 },
    { model = 'comet2',      name = 'Comet',           class = 'SPORT',     price = 125000, power = 8.4, grip = 8.0 },
    { model = 'banshee',     name = 'Banshee',          class = 'SPORT',     price = 105000, power = 8.9, grip = 7.6 },
    { model = 'sultan',      name = 'Sultan',           class = 'SPORT',     price = 75000,  power = 7.8, grip = 7.8 },
    { model = 'sultanrs',    name = 'Sultan RS',        class = 'SUPER',    price = 180000, power = 9.1, grip = 8.2 },
    { model = 'buffalo',     name = 'Buffalo',          class = 'MUSCLE',   price = 52000,  power = 7.4, grip = 6.8 },
    { model = 'dominator',   name = 'Dominator',        class = 'MUSCLE',   price = 65000,  power = 8.0, grip = 6.5 },
    { model = 'futo',        name = 'Futo',             class = 'SPORT',    price = 32000,  power = 5.7, grip = 6.3 },
    { model = 'sentinel',    name = 'Sentinel XS',      class = 'COUPE',    price = 47000,  power = 6.8, grip = 7.1 },
    { model = 'kuruma',      name = 'Kuruma',           class = 'SPORT',    price = 95000,  power = 7.7, grip = 7.9 },
    { model = 'cheetah',     name = 'Cheetah',          class = 'SUPER',    price = 650000, power = 9.0, grip = 8.5 },
}

Config.WheelTypes = {
    { id = 0, name = 'SPORT' },
    { id = 1, name = 'MUSCLE' },
    { id = 2, name = 'LOWRIDER' },
    { id = 3, name = 'SUV' },
    { id = 4, name = 'OFFROAD' },
    { id = 5, name = 'TUNER' },
    { id = 7, name = 'HIGH END' },
}

Config.PaintPresets = {
    { name = 'Pearl',   r = 235, g = 230, b = 214 },
    { name = 'Torch',   r = 220, g = 30,  b = 42 },
    { name = 'Glacier', r = 198, g = 218, b = 226 },
    { name = 'Voltage', r = 245, g = 180, b = 35 },
    { name = 'Abyss',   r = 24,  g = 72,  b = 130 },
    { name = 'Acid',    r = 112, g = 166, b = 45 },
    { name = 'Amethyst',r = 115, g = 46,  b = 143 },
    { name = 'Carbon',  r = 35,  g = 39,  b = 43 },
}

Config.NeonPresets = {
    { name = 'EMBER', r = 242, g = 45,  b = 38 },
    { name = 'ICE',   r = 48,  g = 157, b = 255 },
    { name = 'VIOLET',r = 172, g = 65,  b = 255 },
    { name = 'MINT',  r = 51,  g = 231, b = 180 },
}
