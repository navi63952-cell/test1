fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Afterhours'
description 'GTA V / FiveM vehicle showroom and customizer'
version '1.0.0'

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/app.js',
    'html/browser-preview.js'
}

shared_script 'config.lua'
client_script 'client.lua'
