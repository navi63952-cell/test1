local previewVehicle = nil
local showroomCam = nil
local nuiOpen = false
local cameraAngle = -24.0
local cameraDistance = 6.5
local wheelCount = 0
local liveryCount = 0

local function getVehicleByModel(model)
    for _, vehicle in ipairs(Config.Vehicles) do
        if vehicle.model == model then return vehicle end
    end
    return nil
end

local function getVehicleData()
    local data = {}
    for _, vehicle in ipairs(Config.Vehicles) do
        data[#data + 1] = vehicle
    end
    return data
end

local function updateCamera()
    if not showroomCam or not DoesEntityExist(previewVehicle) then return end
    local center = GetEntityCoords(previewVehicle)
    local heading = GetEntityHeading(previewVehicle) + cameraAngle
    local radians = math.rad(heading)
    local x = center.x - math.sin(radians) * cameraDistance
    local y = center.y + math.cos(radians) * cameraDistance
    SetCamCoord(showroomCam, x, y, center.z + 1.8)
    PointCamAtEntity(showroomCam, previewVehicle, 0.0, 0.35, 0.35, true)
end

local function closeCustomizer(keepVehicle)
    if not nuiOpen then return end
    nuiOpen = false
    SetNuiFocus(false, false)
    SendNUIMessage({ action = 'close' })
    if showroomCam then
        RenderScriptCams(false, true, 450, true, true)
        DestroyCam(showroomCam, false)
        showroomCam = nil
    end
    if previewVehicle and DoesEntityExist(previewVehicle) then
        FreezeEntityPosition(previewVehicle, false)
        SetEntityCollision(previewVehicle, true, true)
        SetVehicleDoorsLocked(previewVehicle, 1)
        if not keepVehicle then DeleteEntity(previewVehicle) end
    end
    previewVehicle = nil
end

local function loadModel(model)
    local hash = joaat(model)
    if not IsModelInCdimage(hash) or not IsModelAVehicle(hash) then return nil end
    RequestModel(hash)
    local timeout = GetGameTimer() + 10000
    while not HasModelLoaded(hash) and GetGameTimer() < timeout do Wait(0) end
    if not HasModelLoaded(hash) then return nil end
    return hash
end

local function setVehicleModel(model)
    local entry = getVehicleByModel(model)
    if not entry then return false, 'That vehicle is not in the showroom list.' end
    local hash = loadModel(model)
    if not hash then return false, 'GTA could not load this vehicle model.' end

    if previewVehicle and DoesEntityExist(previewVehicle) then DeleteEntity(previewVehicle) end
    local player = PlayerPedId()
    local position = GetOffsetFromEntityInWorldCoords(player, 0.0, 7.0, 0.0)
    local heading = GetEntityHeading(player)
    previewVehicle = CreateVehicle(hash, position.x, position.y, position.z, heading, false, false)
    SetModelAsNoLongerNeeded(hash)
    if not DoesEntityExist(previewVehicle) then return false, 'Could not create the preview vehicle.' end

    SetEntityAsMissionEntity(previewVehicle, true, true)
    SetVehicleOnGroundProperly(previewVehicle)
    SetVehicleEngineOn(previewVehicle, true, true, false)
    SetVehicleDoorsLocked(previewVehicle, 2)
    SetVehicleModKit(previewVehicle, 0)
    SetVehicleLights(previewVehicle, 2)
    SetVehicleNumberPlateText(previewVehicle, 'AFTERHRS')
    FreezeEntityPosition(previewVehicle, true)
    updateCamera()
    return true
end

local function openCustomizer()
    if nuiOpen then return end
    nuiOpen = true
    local player = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(player, false)
    local currentModel = 'nero'
    if vehicle ~= 0 then
        currentModel = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle)):lower()
    end
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        vehicles = getVehicleData(),
        paints = Config.PaintPresets,
        neons = Config.NeonPresets,
        wheelTypes = Config.WheelTypes,
        currentModel = getVehicleByModel(currentModel) and currentModel or 'nero'
    })
    local ok = setVehicleModel(getVehicleByModel(currentModel) and currentModel or 'nero')
    if not ok then
        closeCustomizer(false)
        TriggerEvent('chat:addMessage', { args = { '^1AFTERHOURS', 'Could not start the vehicle preview here.' } })
        return
    end
    showroomCam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    updateCamera()
    SetCamFov(showroomCam, 37.0)
    RenderScriptCams(true, true, 600, true, true)
    local modCounts = {}
    for _, modType in ipairs({ 11, 12, 13, 15, 16 }) do modCounts[tostring(modType)] = GetNumVehicleMods(previewVehicle, modType) end
    wheelCount = GetNumVehicleMods(previewVehicle, 23)
    liveryCount = math.max(GetVehicleLiveryCount(previewVehicle), GetNumVehicleMods(previewVehicle, 48), 0)
    if liveryCount > 0 then
        if GetVehicleLivery(previewVehicle) < 0 then SetVehicleLivery(previewVehicle, 0) end
        if GetVehicleMod(previewVehicle, 48) < 0 then SetVehicleMod(previewVehicle, 48, 0, false) end
    end
    SetVehicleCustomPrimaryColour(previewVehicle, 235, 230, 214)
    SetVehicleCustomSecondaryColour(previewVehicle, 205, 35, 42)
    SendNUIMessage({ action = 'vehicleSelected', model = currentModel, modCounts = modCounts, wheelCount = wheelCount, wheelType = GetVehicleWheelType(previewVehicle), liveryCount = liveryCount })
end

RegisterCommand('atelier', openCustomizer, false)
RegisterKeyMapping('atelier', 'Open Afterhours vehicle customizer', 'keyboard', 'F7')

RegisterNUICallback('close', function(_, cb)
    closeCustomizer(false)
    cb({ ok = true })
end)

RegisterNUICallback('selectVehicle', function(data, cb)
    local ok, err = setVehicleModel(tostring(data.model or ''))
    if ok then
        local modCounts = {}
        for _, modType in ipairs({ 11, 12, 13, 15, 16 }) do modCounts[tostring(modType)] = GetNumVehicleMods(previewVehicle, modType) end
        wheelCount = GetNumVehicleMods(previewVehicle, 23)
        liveryCount = math.max(GetVehicleLiveryCount(previewVehicle), GetNumVehicleMods(previewVehicle, 48), 0)
        if liveryCount > 0 then
            if GetVehicleLivery(previewVehicle) < 0 then SetVehicleLivery(previewVehicle, 0) end
            if GetVehicleMod(previewVehicle, 48) < 0 then SetVehicleMod(previewVehicle, 48, 0, false) end
        end
        SetVehicleCustomPrimaryColour(previewVehicle, 235, 230, 214)
        SetVehicleCustomSecondaryColour(previewVehicle, 205, 35, 42)
        SendNUIMessage({ action = 'vehicleSelected', model = data.model, modCounts = modCounts, wheelCount = wheelCount, wheelType = GetVehicleWheelType(previewVehicle), liveryCount = liveryCount })
    else
        SendNUIMessage({ action = 'error', message = err })
    end
    cb({ ok = ok, error = err })
end)

RegisterNUICallback('customize', function(data, cb)
    if not previewVehicle or not DoesEntityExist(previewVehicle) then cb({ ok = false }); return end
    local vehicle = previewVehicle
    local section = tostring(data.section or '')

    if section == 'paint' then
        local r, g, b = tonumber(data.r) or 220, tonumber(data.g) or 30, tonumber(data.b) or 42
        local finishes = { gloss = 1, satin = 3, metallic = 1 }
        SetVehicleModColor_1(vehicle, finishes[tostring(data.finish)] or 1, 0, 0)
        SetVehicleCustomPrimaryColour(vehicle, math.floor(r), math.floor(g), math.floor(b))
        if liveryCount > 0 then
            SetVehicleCustomSecondaryColour(vehicle, 205, 35, 42)
        else
            SetVehicleCustomSecondaryColour(vehicle, math.floor(r), math.floor(g), math.floor(b))
        end
    elseif section == 'wheelType' then
        local wheelType = math.max(0, math.min(7, math.floor(tonumber(data.value) or 0)))
        SetVehicleWheelType(vehicle, wheelType)
        SetVehicleMod(vehicle, 23, -1, false)
        wheelCount = GetNumVehicleMods(vehicle, 23)
        SendNUIMessage({ action = 'wheelTypeChanged', wheelType = wheelType, wheelCount = wheelCount })
    elseif section == 'wheel' then
        local count = GetNumVehicleMods(vehicle, 23)
        local index = math.max(-1, math.min(count - 1, math.floor(tonumber(data.value) or -1)))
        SetVehicleMod(vehicle, 23, index, false)
        SetVehicleMod(vehicle, 24, index, false)
    elseif section == 'performance' then
        local modType = math.floor(tonumber(data.modType) or -1)
        local count = GetNumVehicleMods(vehicle, modType)
        local index = math.max(-1, math.min(count - 1, math.floor(tonumber(data.value) or -1)))
        if modType >= 0 and modType <= 16 then SetVehicleMod(vehicle, modType, index, false) end
    elseif section == 'windowTint' then
        SetVehicleWindowTint(vehicle, math.max(0, math.min(6, math.floor(tonumber(data.value) or 0))))
    elseif section == 'neon' then
        local r, g, b = tonumber(data.r) or 242, tonumber(data.g) or 45, tonumber(data.b) or 38
        for i = 0, 3 do SetVehicleNeonLightEnabled(vehicle, i, data.enabled == true) end
        SetVehicleNeonLightsColour(vehicle, math.floor(r), math.floor(g), math.floor(b))
    elseif section == 'xenon' then
        ToggleVehicleMod(vehicle, 22, data.enabled == true)
        SetVehicleXenonLightsColor(vehicle, math.max(0, math.min(12, math.floor(tonumber(data.color) or 0))))
    elseif section == 'livery' then
        local count = GetVehicleLiveryCount(vehicle)
        local modCount = GetNumVehicleMods(vehicle, 48)
        local index = math.floor(tonumber(data.value) or 0)
        if count > 0 then SetVehicleLivery(vehicle, math.max(0, math.min(count - 1, index))) end
        if modCount > 0 then SetVehicleMod(vehicle, 48, math.max(0, math.min(modCount - 1, index)), false) end
    end
    cb({ ok = true })
end)

RegisterNUICallback('camera', function(data, cb)
    cameraAngle = tonumber(data.angle) or cameraAngle
    cameraDistance = math.max(4.0, math.min(10.0, tonumber(data.distance) or cameraDistance))
    updateCamera()
    cb({ ok = true })
end)

RegisterNUICallback('takeBuild', function(_, cb)
    if previewVehicle and DoesEntityExist(previewVehicle) then
        local vehicle = previewVehicle
        closeCustomizer(true)
        SetVehicleDoorsLocked(vehicle, 1)
        SetPedIntoVehicle(PlayerPedId(), vehicle, -1)
    else
        closeCustomizer(false)
    end
    cb({ ok = true })
end)

CreateThread(function()
    while true do
        if nuiOpen then
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 75, true)
            Wait(0)
        else
            Wait(500)
        end
    end
end)

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then closeCustomizer(false) end
end)
