# AFTERHOURS Customs — FiveM resource

A GTA V / FiveM vehicle picker and customizer. The interface is an NUI overlay; the preview is the selected **GTA V vehicle model rendered by the game**. This avoids the flat hand-drawn car from the earlier web mockup.

## Included

- Select from 19 vanilla GTA V vehicles, with class filters and search.
- Change custom body colour and finish, wheel family and rim, neon, window tint, xenon lights, and supported performance mods.
- Orbit and zoom the GTA camera around the frozen preview vehicle.
- Cancel with Escape or **Take This Build** to enter the selected car.
- No framework dependency and no add-on vehicle assets required.

The displayed price is a portfolio/demo estimate. This standalone resource does not charge an account, persist ownership, or synchronize a purchased car through a roleplay economy. Server-specific ownership and billing require integration with that server's framework.

## Install (requires GTA V and a FiveM server)

1. Copy the `afterhours_fivem` folder into the server's `resources/[local]/` directory.
2. Add `ensure afterhours_fivem` to `server.cfg`.
3. Start the server, join using FiveM, and press **F7** (or enter `/atelier`).

To preview the interface without FiveM, open `html/index.html` in a browser. It now loads a sample vehicle list and explains that the live car is only rendered by GTA V. Browser controls are visual only.

Use it in an open space or a tuning garage. The preview vehicle spawns locally in front of the player. Escape cancels and removes it; Take This Build exits the menu and puts the player in it.

## Important limits

- GTA V and FiveM are required to see the live car preview. The workspace does not include either, so the resource has not been run in-game here.
- The vehicle list uses standard game models. Add-on vehicles can be added to `config.lua` only when the server already streams those models.
- This is a client-side portfolio prototype. A public roleplay server should connect the final purchase to its server-side permission, money, and vehicle persistence systems.
- Fonts are loaded from Google Fonts when the game can reach the internet; the UI has system font fallbacks.

## Files

- `fxmanifest.lua` — FiveM resource manifest and NUI entry point.
- `config.lua` — vehicle catalogue, wheel families, paint and neon palettes.
- `client.lua` — GTA vehicle spawn, preview camera, native modifications, and NUI callbacks.
- `html/` — vehicle catalogue, customizer interface, styles, and NUI logic.
